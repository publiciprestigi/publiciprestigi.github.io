<!-- intro -->
El primer Top 25 recull els directors amb més presència acumulada als quatre festivals. Sumant, primer, el total dels films seleccionats i, després, amb el símbol ★ el número dels que han sigut premiats. I a continuació, el resultat de cada festival seguint la mateixa pauta.

En cas d'empat, el criteri és el nombre de premis i després el valor del festival, que segueix la jerarquia: Cannes > Venècia > Berlín > Sant Sebastià. Així, un director amb 3 participacions a Cannes es posiciona per davant d'un altre amb 3 a Sant Sebastià.

En el següent Top 10 s'exclou Sant Sebastià per aïllar la projecció als tres festivals històricament més prestigiosos internacionalment. Els empats es resolen amb la mateixa metodologia.

<!-- /intro -->

<!-- comentari-top25 -->
- Saura lidera amb 17 pel·lícules seleccionades —*Peppermint Frappé* (1968) va participar simultàniament a Cannes i Berlín, un cas excepcional de l'època— i 8 d'elles premiades, Almodóvar el segueix amb 11 i 6. En nombre Saura és dominant, però Almodóvar és pràcticament l'únic pont sòlid entre públic i prestigi que apareix tant al Top 100 per espectadors com al circuit de festivals internacionals de manera sostinguda.

- Dels 25 directors d'aquest rànquing, només 5 coincideixen a la vegada al Top 100 d'espectadors: el citat Almodóvar (*Mujeres al borde…* i *Todo sobre mi madre*), Fernando León de Aranoa (*Los lunes al sol*), Vicente Aranda (*Juana la Loca*), Pedro Olea (*Tormento*) i Mario Camus (*Los santos inocentes*).
<!-- /comentari-top25 -->

<!-- comentari-top10 -->
- Com canvia el rànquing: Montxo Armendáriz (#5 al Top 25), Gonzalo Suàrez (#6), Imanol Uribe (#9) i Icíar Bollaín (#10) desapareixen del Top 10 sense Sant Sebastià. I es mantenen Saura, Almodóvar, Mario Camus, Manuel Gutiérrez Aragón, Vicente Aranda i Bigas Luna.
 
- En canvi, apareixen: Fernando Trueba (#11→#6), Isabel Coixet (#18→#7), Ricardo Franco (→#9), Víctor Erice (#21→#10). I es revela quins directors han tingut una projecció veritablement internacional més enllà del festival de Sant Sebastià.
<!-- /comentari-top10 -->

<!-- comentari-top3 -->
**Recordatori**: es consideren films premiats els que han rebut el guardó màxim del festival, especials del jurat, millor direcció, millors interpretacions o millor guió.
<!-- /comentari-top3 -->
