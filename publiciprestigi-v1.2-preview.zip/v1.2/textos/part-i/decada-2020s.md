<!-- intro -->
El col·lapse pandèmic i la recuperació lenta. El mercat cau fins als 50 milions d’entrades el 2020 i el 2025 encara es mou per sota dels 65 milions. En aquest context deprimit, la saga *Padre no hay más que uno* es converteix en l’única gran resistència del cinema popular: tres entregues entren al Top 100 i totes superen el llindar aproximat dels 2 milions d’espectadors. L’IIC de la tercera entrega (3,07), el més alt de la dècada, confirma la força d’aquest vincle amb el públic familiar en un mercat encara en recomposició.
<!-- /intro -->
