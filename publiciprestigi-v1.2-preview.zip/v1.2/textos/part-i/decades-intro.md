<!-- intro -->
Resum cronològic de les pel·lícules líder de cada dècada. Les mètriques de cada film (espectadors, penetració i IIC) responen a l'any d'estrena real, mentre que la columna de mercat mostra la mitjana anual de la dècada corresponent.
<!-- /intro -->

<!-- intermedi -->
Veiem ara com es distribueixen per dècades les 100 pel·lícules espanyoles amb més espectadors al llarg de tot el període estudiat:
<!-- /intermedi -->

<!-- comentari -->
La distribució per dècades és molt desigual i reflecteix el canvi profund del mercat cinematogràfic espanyol. El tram inicial 1965-1969 acapara el 43% del Top 100 perquè el cinema encara era el gran espectacle popular de masses. Els anys setanta encara mantenen una presència important (18%), però el descens ja és evident.

La caiguda abrupta dels vuitanta (3%) marca el canvi d’època: universalització de la televisió, irrupció del vídeo domèstic i transformació del model de producció amb el Decret Miró <sup>[5]</sup>, en un context en què el cinema en sales deixa de tenir la centralitat social i comercial de les dècades anteriors.

Als noranta la recuperació encara és tímida (6%), però als 2000s (14%) i als 2010s (13%) apareix un nou escenari: un mercat molt més petit, però capaç de generar èxits puntuals de gran impacte. Als 2020s, en canvi, tot torna a caure (3%) amb el col·lapse pandèmic i l’explosió definitiva de les plataformes.
<!-- /comentari -->
