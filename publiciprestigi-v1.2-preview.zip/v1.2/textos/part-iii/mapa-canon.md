<!-- intro -->
Tres intents en les últimes tres dècades han volgut fixar per consens quines són les millors pel·lícules del cinema espanyol: la llista del Centenari (1995), impulsada per l'ICAA amb motiu dels cent anys del naixement del cinema; l'enquesta de *Caimán Cuadernos de Cine* (2016), d'arrel cinèfila; i la del suplement *Babelia* de *El País* (2025), de perfil periodístic. Tres prescriptors de naturalesa diferent, tres moments, tres fotografies del cànon. <sup>[21]</sup>

Aquest capítol les creua per dibuixar-ne un possible consens compartit i el situa davant del públic real del període estudiat. Després dels festivals i els seus premis, el cànon és una forma de prestigi i legitimitat que l'estudi encara no havia tractat, i la pregunta és directa: quants espectadors té al darrere?

El resultat és un mapa amb un nucli central de consens i quatre zones al voltant: un extrem radical gairebé sense taquilla, un extrem popular sense cap presència a les llistes, i dos espais intermedis, la generació actual i el cinema popular de gènere. Cinc zones que reuneixen, en un sol gràfic, tots els territoris que l'estudi ha anat recorrent.
<!-- /intro -->

<!-- fonts -->
| | Centenari (1995) | Caimán (2016) | Babelia (2025) |
| --- | --- | --- | --- |
| **Perfil** | Institucional (Comissió del Centenari del Cinema) | Cinèfil (*Caimán Cuadernos de Cine*) | Periodístic (suplement *Babelia*, *El País*) |
| **Votants** | Acadèmia, actors, historiadors, directors, guionistes i crítica | 350 crítics, historiadors, investigadors, periodistes i altres especialistes | 53 periodistes, crítics i col·laboradors de l'àrea cultural del diari |
| **Abast** | Tot el cinema espanyol fins al 1995 | Tot, fins al 2016 | Només 1975–2025 |
| **Format** | 42 títols, ordre cronològic, sense rànquing | 455 títols votats, jerarquitzats per punts | 50 títols, jerarquitzats |
<!-- /fonts -->

<!-- criteri -->
El criteri general d’entrada al nucli central és la presència a totes les llistes que cronològicament poden incloure cada film: les tres per al període 1975–1995, i les dues disponibles per als trams anterior (la llista de *Babelia* comença el 1975) i posterior (la del Centenari acaba el 1995). Per als films posteriors a 1995 s’hi afegeix una condició coherent amb el mapa mateix: un lloc rellevant en aquest estudi, per gran taquilla i/o reconeixement a festivals. El mapa només admet una excepció a aquest criteri.

Cal tenir present l'abast d'aquest mapa: cobreix el període de l'estudi (1965–2025) i no és, per tant, el cànon complet del cinema espanyol. En queden fora títols clau d'abans del període com *Viridiana* de Buñuel, *Plácido*, *El verdugo* i *¡Bienvenido, Mister Marshall!* de Berlanga, o *Muerte de un ciclista* i *Calle Mayor* de Bardem, habituals a les primeres posicions de qualsevol cànon històric. Aquesta absència explica que Berlanga hi entri excepcionalment per *La escopeta nacional*, absent de la llista del Centenari però avalada per *Caimán* i *Babelia* i convertida en la seva obra més reconeguda dins del període, mentre que Bardem no hi té cap film.

L'ordre dels cinc blocs no és arbitrari: el mapa es llegeix com una escala d'espectadors, de l'extrem radical, on el públic gairebé desapareix, fins a l'extrem popular, on ho és tot. Les mitjanes de cada bloc dibuixen la corba: 24K espectadors a l'extrem radical, 354K a la generació actual, 1,4M al nucli central, 3,2M al popular de gènere i 5,1M a l'extrem popular. El nucli ocupa exactament el lloc que li correspon: el mig.
<!-- /criteri -->

<!-- nucli -->
## El nucli central

Setze films de *La caza* (1966) a *La isla mínima* (2014), i una constant que cap altre bloc comparteix: el públic mai no hi és residual. Cap film per sota dels 220.000 espectadors, cap per sobre dels 3,6 milions: 5 títols es mouen per sota del mig milió, 10 superen el milió i només 2 passen dels tres milions (*Furtivos* i *Mujeres al borde de un ataque de nervios*, curiosament dos 'dobles corones'). El nucli no viu als extrems: és la zona on el consens crític i una audiència àmplia han coincidit.

La seva columna vertebral són els cinc directors de màxim consens: Buñuel, Berlanga, Saura, Erice i Almodóvar, tots amb almenys un film al nucli. Les proporcions internes també parlen: Erice hi té dos títols amb només quatre llargmetratges de filmografia, el màxim consens amb el mínim volum d'obra, i Almodóvar tres, el màxim de qualsevol director del mapa. I podrien ser més: té 7 títols al top 100 de *Caimán* i 7 al top 50 de *Babelia*, i dos d'ells, *Hable con ella* i *La ley del deseo*, apareixen a totes dues llistes i queden fora del nucli només per l'absència a la llista del Centenari.

Dos noms més completen el consens ampliat. De Bardem, sense cap film del període a les llistes, l'únic film que apareix citat a l'estudi és *Varietés* (1971), obra poc reconeguda amb Sara Montiel que va superar el milió i mig d'espectadors. I Fernán Gómez entra amb *El viaje a ninguna parte*, tot i que la seva canonització creixent es deu també al redescobriment de l'obra dels 50 i 60 (*El extraño viaje*, *El mundo sigue*), que la cinefília ha situat al top 10 de *Caimán*, el cas més clar de cànon retroactiu.

La resta del nucli el completen títols de trajectòries molt diverses: hi conviuen *El desencanto*, l'únic documental de tot el mapa, i *La isla mínima* d'Alberto Rodríguez, l'entrada més recent. *Amantes* i *Belle Époque* marquen les dues últimes vegades que la llista institucional, la cinèfila i la periodística coincideixen plenament, els últims exponents del model que havia dominat els 80 i primers 90, just abans del relleu generacional. I *Te doy mis ojos* hi afegeix una última dada: és l'únic film del nucli dirigit per una dona, el contrapunt exacte de la majoria femenina de la generació actual.
<!-- /nucli -->

<!-- intermedis -->
## Els espais intermedis

A banda i banda del nucli, dos grups comparteixen una posició intermèdia: el cànon en construcció de la generació actual i el cinema popular de gènere, territori del cinema d’autor industrial ja tractat a l’estudi, ara mirat des del cànon.

Per una banda, la generació actual: quatre films del 2022 i un precedent del 2014. La fotografia és nítida: tres directores i dos directors, la primera zona del mapa amb majoria femenina, en coherència amb el canvi estructural documentat. La seva escala de públic va dels 43K espectadors de *La maternal* al 1,1M d'*As bestas*. *Magical Girl*, Conxa d'Or el 2014, és el precedent i alhora l'avís: present a la llista de *Caimán* el 2016, absent de la de *Babelia* el 2025, potser condicionada també per les acusacions contra el seu director publicades l’any anterior pel mateix diari. <sup>[22]</sup> El cànon en construcció també es pot refredar. I fora del mapa per pura cronologia queda *Los domingos*, estrenada quatre mesos després de l'enquesta de *Babelia*: la primera candidata de la propera llista, i probablement la que substituirà *Cinco lobitos*, de la mateixa directora.

I per l'altra banda, el cinema popular de gènere que reneix a mitjans dels anys 90, amb una nova generació de directors que transforma definitivament el cinema comercial espanyol. I el seu patró intern és revelador: *El día de la bestia*, *Tesis* i *REC* apareixen a les llistes; *Los otros* i *Lo imposible*, els dos grans èxits de públic posteriors, no. El cas Amenábar ho condensa: *Tesis* (1996), el seu debut, és present a les llistes de *Caimán* i *Babelia*; *Los otros* (2001), amb més de 6 milions d'espectadors, no hi és. El cànon els accepta com a promeses i els ignora com a fenòmens de masses (amb l'excepció parcial, val a dir, de *Mar adentro*, que sí que apareix a la llista periodística, al lloc 36).

El patró, a més, té precedents. Narciso Ibáñez Serrador (el gran padrí d'aquesta generació) va conèixer les dues cares en ordre invers: *La residencia* (1969), el seu gran èxit de taquilla, no apareix a cap llista, mentre que *¿Quién puede matar a un niño?* (1976), bastant menys vista al seu moment, s'ha convertit amb el temps en títol de culte amb doble presència canònica. I Antonio Isasi-Isasmendi, l'autor més ambiciós del gènere internacional dels 60 i 70, amb tres films al Top 100 d'espectadors, no ha entrat mai a cap llista.
<!-- /intermedis -->

<!-- extrems -->
## Els extrems

Als marges del mapa, les dues situacions límit: el cànon gairebé sense públic i el públic sense cap cànon.

A l'extrem radical, cap dels cinc films per sobre dels 80.000 espectadors. És el territori de la canonització cinèfila i crítica. *Arrebato* n'és el cas paradigmàtic: poc públic a l'estrena en sales, revaloritzada en el temps, avui número 1 de Babelia i 5 de *Caimán*. Portabella, Guerín i Serra tenen diversos títols a les llistes, i el mapa recull el més ben situat de cadascun. Completa el bloc el Jordà de *De nens*, present a *Caimán* i *Babelia*, que amb Portabella (i el Jacinto Esteva de *Lejos de los árboles*, també a la llista de *Caimán*) situa l'Escola de Barcelona com la tradició radical amb més pes al cànon cinèfil. I, més recentment, *El año del descubrimiento* (2020) de Luis López Carrasco (número 19 de *Babelia*, 6.600 espectadors) és la prova que la via de canonització sense públic segueix plenament activa. <sup>[23]</sup>

A l'extrem popular, més de 25 milions d'espectadors acumulats entre els cinc films i zero presència a les llistes. Del duo Paco Martínez Soria i Pedro Lazaga a l'èxit apabullant d'*Ocho apellidos vascos* d'Emilio Martínez-Lázaro (guanyador, també, d'un Os d'Or a Berlín per *Las palabras de Max*, d'extrem a extrem), passant pel 'landisme' de *No desearás al vecino del quinto*, les comèdies musicals de Manolo Escobar i Concha Velasco com *Pero... ¿en qué país vivimos?*, i el fenomen de la saga Torrente de Santiago Segura. La seva memòria persisteix en la cultura popular, però ocupa un lloc marginal en l’acadèmia i les institucions.
<!-- /extrems -->

<!-- tancament -->
El mapa demostra que el nucli central del cànon s’ha construït amb audiències àmplies, però no desmesurades. Als extrems, en canvi, conviuen dues formes oposades de posteritat: pel·lícules de públic reduït que el cànon ha mantingut vives i grans èxits populars que no han estat incorporats al seu relat. La pregunta oberta és què passarà amb els espais intermedis: si el cinema popular de gènere acabarà entrant pel pes del temps o per futurs redescobriments, i si la generació actual consolidarà o ampliarà les seves posicions quan apareguin noves llistes i nous títols. Perquè el cànon no està mai tancat i varia segons qui el mira: la pel·lícula que encapçala la llista més recent de *Babelia* ni tan sols apareixia entre els millors títols de la primera llista del Centenari.

Les formes canviants de veure cinema condicionaran el futur cànon? Els espectadors de sala mantindran el mateix pes? S'eixamplarà la distància entre la visió cinèfila, periodística i institucional?
<!-- /tancament -->
